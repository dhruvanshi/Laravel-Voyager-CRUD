<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

$namespace = '\Fen\Fenbooth\Http\Controllers';

// Route::group([
//     'prefix' => 'person', // Must match its `slug` record in the DB > `data_types`
//     'middleware' => ['web'],
//     'as' => 'voyager-person.person.',
//     'namespace' => $namespace,
// ], function () {
//     Route::get('/', ['uses' => 'PersonController@getPosts', 'as' => 'list']);
//     Route::get('{slug}', ['uses' => 'PersonController@getPost', 'as' => 'post']);
// });

Route::get('fenbooth', function () {
    return 'welcome to fenbooth package.';
});

// Route::get('fenview', function () {
//     return view('fenbooth::fenview');
// });

// Route::get('inspire', function(Fen\Fenbooth\Fenbooth $inspire) {
//     return $inspire->justDoIt();
// });

// Route::resource('fen','Fen\Fenbooth\Http\Controllers\FenboothController');

// Clear all cache:
Route::get('/clear-all-cache', function() {
    Artisan::call('cache:clear');
	Artisan::call('route:cache');
 	Artisan::call('config:cache');
    Artisan::call('view:clear');
    return 'Cache has been cleared';
});

// Clear application cache:
Route::get('/clear-cache', function() {
    Artisan::call('cache:clear');
    return 'Application cache has been cleared';
});

//Clear route cache:
Route::get('/route-cache', function() {
	Artisan::call('route:cache');
    return 'Routes cache has been cleared';
});

//Clear config cache:
Route::get('/config-cache', function() {
 	Artisan::call('config:cache');
 	return 'Config cache has been cleared';
}); 

// Clear view cache:
Route::get('/view-clear', function() {
    Artisan::call('view:clear');
    return 'View cache has been cleared';
});