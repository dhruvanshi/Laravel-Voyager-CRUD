@section('meta_title', 'collection')
@section('meta_description', 'collection')
@section('page_title', 'collection')

@foreach($collections as $collection)
    {!! $collection->title !!}
    {!! $collection->body !!}
@endforeach