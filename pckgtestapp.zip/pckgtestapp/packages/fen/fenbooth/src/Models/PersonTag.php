<?php

namespace Fen\Fenbooth\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class PersonTag extends Model
{
    use HasFactory;

    protected $table = 'person_tag';

    public const STATUS_ACTIVE = 'ACTIVE';
    public const STATUS_INACTIVE = 'INACTIVE';

    public function person()
    {
        return $this->belongsToMany(Person::class, 'person_person_tag');
    }

}
