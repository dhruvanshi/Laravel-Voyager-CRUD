<?php

namespace Fen\Fenbooth\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class PersonPersonTag extends Model
{
    use HasFactory;

    protected $table = 'person_person_tag';
}
