<?php

namespace Fen\Fenbooth\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Person extends Model
{
    use HasFactory;
    
    protected $table = 'person';

    public const STATUS_ACTIVE = 'ACTIVE';
    public const STATUS_INACTIVE = 'INACTIVE';
    
    public function person_tag()
    {
        return $this->belongsToMany(PersonTag::class, 'person_person_tag');
    }
}
