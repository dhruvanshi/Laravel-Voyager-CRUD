<?php

namespace Fen\Fenbooth\Console\Commands;

use Illuminate\Console\Command;

class PublishCommand extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'fenbooth:publish';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Installing additional functionality to voyager package';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        $this->info('Migrating the database tables into your application');
        $this->call('migrate');
        $this->info('Attempting to crete model');
        $this->warn('Model not created yet');
        
        return 0;
    }
}
