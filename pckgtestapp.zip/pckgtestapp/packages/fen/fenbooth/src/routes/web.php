<?php

use Illuminate\Support\Facades\Route;
use Fen\Fenbooth\Http\Controllers;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('fenbooth', function () {
    return 'welcome to fenbooth package.';
});

Route::get('fenview', function () {
    return view('fenbooth::fenview');
});

Route::get('inspire', function(Fen\Fenbooth\Fenbooth $inspire) {
    return $inspire->justDoIt();
});

Route::resource('fen','Fen\Fenbooth\Http\Controllers\FenboothController');


