<?php

namespace Fen\Fenbooth\Providers;

use Fen\Fenbooth\Console\Commands\PublishCommand;
use Illuminate\Support\ServiceProvider;

class FenBoothServiceProvider extends ServiceProvider
{
    /**
     * Our root directory for this package to make traversal easier
     */
    const PACKAGE_DIR = __DIR__ . '/../../';
    
    /**
     * Register services.
     *
     * @return void
     */
    public function register()
    {
        //
    }

    /**
     * Bootstrap services.
     *
     * @return void
     */
    public function boot()
    {
        $this->loadRoutesFrom(__DIR__.'/../routes/web.php');
        $this->loadViewsFrom(__DIR__.'/../resources/views', 'fenbooth');
        $this->loadMigrationsFrom(__DIR__.'/../database/migrations');

        if ($this->app->runningInConsole()) {
            $this->commands([
                PublishCommand::class,
                // InstallCommand::class,
                // NetworkCommand::class,
            ]);
        }
    }
}
