<?php

namespace Fen\Fenbooth\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Auth;
use TCG\Voyager\Facades\Voyager;
use TCG\Voyager\Traits\Resizable;
use TCG\Voyager\Traits\Translatable;

class PersonPersonTag extends Model
{
    use HasFactory, Translatable, Resizable;

    protected $table = 'person_person_tag';
}
