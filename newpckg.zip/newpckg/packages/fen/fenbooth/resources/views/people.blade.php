@section('meta_title', $person->title)
@section('meta_description', $person->meta_description)
@section('page_title', $person->title)
@section('page_subtitle', 'People // ' . $person->created_at->format('jS M. Y'))

{!! $person->body !!}
